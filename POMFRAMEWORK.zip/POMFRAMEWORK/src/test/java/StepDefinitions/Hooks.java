package StepDefinitions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.google.common.io.Files;
import com.vimalselvam.cucumber.listener.Reporter;


import BaseClass.browsersetup;
import PageObjectory.LoginPage;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends browsersetup {
	LoginPage lg;
	static String configfilepath = System.getProperty("user.dir") + "//config//file.properties";
	static Properties prop;
	static FileInputStream fileInput;
	
	

	public static void Configuration() {
		try {
			fileInput = new FileInputStream(configfilepath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		prop = new Properties();
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void setUp(Scenario scenario) throws InterruptedException {
		  
		System.out.println("Open browser");
		Configuration();
		driver = browsersetup.startBrowser(prop.getProperty("browserName"), prop.getProperty("url"));
		lg = new LoginPage(driver);
		lg.UserName(prop.getProperty("Username"));
		 lg.ContinueBtn();
		lg.Password(prop.getProperty("Password"));
		lg.LogOnBtn();
		browsersetup.loadPage(10000);
	}

	@After(order = 1)
	public void afterScenario(Scenario scenario) {
		if (scenario.isFailed()) {
			String screenshotName = scenario.getName();
			try {
			//	String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
				TakesScreenshot scrShot = ((TakesScreenshot) driver);
				File sourcePath = scrShot.getScreenshotAs(OutputType.FILE);
				File destinationPath = new File(System.getProperty("user.dir")  + "//target//cucumber-reports//" + screenshotName + ".png");
				Files.copy(sourcePath, destinationPath);
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	

	@After(order = 0)
	public void AfterSteps() {
		driver.quit();
	}

}
