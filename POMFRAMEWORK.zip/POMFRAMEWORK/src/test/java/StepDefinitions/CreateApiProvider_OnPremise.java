package StepDefinitions;

import org.junit.Assert;

import BaseClass.browsersetup;
import PageObjectory.CreateApiProvider_OnPremisePage;
import Utilities.util;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class CreateApiProvider_OnPremise extends browsersetup{
	
	CreateApiProvider_OnPremisePage CAPOP;
	util ut;
	
	@Given("^User click on Configure tab$")
	public void user_click_on_Configure_tab() throws Throwable {
		browsersetup.loadPage(10000);
		CAPOP =  new CreateApiProvider_OnPremisePage(driver);
		CAPOP.clickOnConfigureTab();
	}

	@Then("^User click on Create button$")
	public void user_click_on_Create_button() throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.clickOnCreateBtn();
	    
	}

	@Then("^User enters the name\"([^\"]*)\" and description\"([^\"]*)\" under Overview$")
	public void user_enters_the_name_and_description_under_Overview(String Name, String Description) throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.setName(Name);
		CAPOP.setDescription(Description);
	}

	@Then("^User click on Connection link$")
	public void user_click_on_Connection_link() throws Throwable {
		browsersetup.loadPage(2000);
		CAPOP.ClickOnConnectionLink();
	    
	}

	@Then("^User selects type\"([^\"]*)\"$")
	public void user_selects_type(String Type) throws Throwable {
		browsersetup.loadPage(2000);
		CAPOP.ClickOnConnection_Type();
		browsersetup.loadPage(2000);
	    ut =  new util(driver);
		ut.ListValues(CAPOP.Connection_TypeList(), Type);
		browsersetup.loadPage(2000);
	    
	}

	@Then("^User enters Host\"([^\"]*)\", Port\"([^\"]*)\" and LocationId\"([^\"]*)\"$")
	public void user_enters_Host_Port_and_LocationId(String Host, String Port, String LocationId) throws Throwable {
		
		CAPOP.Connection_Host(Host);
		CAPOP.Connection_Port(Port);
		CAPOP.Connection_LocationId(LocationId);
		browsersetup.loadPage(2000);
	}

	@Then("^User selects AdditionalProperties\"([^\"]*)\" and enter data\"([^\"]*)\"$")
	public void user_selects_AdditionalProperties_and_enter_data(String AdditionalProperties, String Data) throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.ClickOnConnection_AdditionalProperties();
		browsersetup.loadPage(2000);
	    ut =  new util(driver);
		ut.ListValues(CAPOP.Connection_AdditionalPropertiesList(), AdditionalProperties);
		browsersetup.loadPage(2000);
		CAPOP.Connection_Input_AdditionalProperties(Data);
		browsersetup.loadPage(2000);
	    
	}

	@Then("^User click on Catalog Service Settings link$")
	public void user_click_on_Catalog_Service_Settings_link() throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.ClickOnCatalogServiceSettings();
	    
	}

	@Then("^User enters Path Prefix\"([^\"]*)\"$")
	public void user_enters_Path_Prefix(String PathPrefix) throws Throwable {
		browsersetup.loadPage(1000);
		CAPOP.PathPrefix(PathPrefix);
	    
	}

	@Then("^User enters Service Collection URL\"([^\"]*)\"$")
	public void user_enters_Service_Collection_URL(String ServiceCollectionURL) throws Throwable {
		CAPOP.ServiceCollectionUrl(ServiceCollectionURL);
		browsersetup.loadPage(1000);
	    
	}

	@Then("^User click Authentication type\"([^\"]*)\"$")
	public void user_click_Authentication_type(String AuthenticationType) throws Throwable {
		CAPOP.ClickOnAutheticationType();
		browsersetup.loadPage(2000);
	    ut =  new util(driver);
		ut.ListValues(CAPOP.AutheticationType_List(), AuthenticationType);
	    
	}

	@Then("^User enters Username\"([^\"]*)\" and Password\"([^\"]*)\"$")
	public void user_enters_Username_and_Password(String UserName, String Password) throws Throwable {
		browsersetup.loadPage(1000);
		CAPOP.UserName(UserName);
		browsersetup.loadPage(500);
		CAPOP.Password(Password);
		browsersetup.loadPage(500);
	    
	}

	@Then("^User click on save button$")
	public void user_click_on_save_button() throws Throwable {
	    
		CAPOP.SaveBtn();
		browsersetup.loadPage(5000);
	}

	@Then("^User enters Host\"([^\"]*)\", Port\"([^\"]*)\"$")
	public void user_enters_Host_Port(String Host, String Port) throws Throwable {
		CAPOP.Connection_Host(Host);
		CAPOP.Connection_Port(Port);
		browsersetup.loadPage(5000);
	}
	
	@Then("^User click on Test Connection button$")
	public void user_click_on_Test_Connection_button() throws Throwable {
		CAPOP.TestConnectionBtn();
		browsersetup.loadPage(2000);
	}

	
	@Then("^Verify Test Connection successfully$")
	public void verify_Test_Connection_successfully() throws Throwable {
		String ExpectedMessage = "Connection to the system was successful with response code : 200; Message : OK";
	    String TestConnectionMessage = CAPOP.TestConnectionSuccessMessage();
	    System.out.println(TestConnectionMessage);
	   Assert.assertEquals(ExpectedMessage, TestConnectionMessage);
		browsersetup.loadPage(2000);
	}

	

}
