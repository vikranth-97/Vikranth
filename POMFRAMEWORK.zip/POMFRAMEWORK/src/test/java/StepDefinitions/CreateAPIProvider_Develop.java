package StepDefinitions;

import BaseClass.browsersetup;
import PageObjectory.CreateApiProvider_OnPremisePage;
import Utilities.util;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CreateAPIProvider_Develop extends browsersetup{
	
	CreateApiProvider_OnPremisePage CAPOP;
	util ut;
	
	@Given("^User click on Develop tab$")
	public void user_click_on_Develop_tab() throws Throwable {
		browsersetup.loadPage(10000);
		CAPOP =  new CreateApiProvider_OnPremisePage(driver);
		CAPOP.DevelopTab();
	   
	}

	@Then("^User click on Develop Create button$")
	public void user_click_on_Develop_Create_button() throws Throwable {
	    
		browsersetup.loadPage(5000);
		CAPOP.Develop_CreateButon();
	}

	@Then("^User select API Provider\"([^\"]*)\"$")
	public void user_select_API_Provider(String APIProvider) throws Throwable {
	    
		browsersetup.loadPage(5000);
	    CAPOP.APIProvider_Dropdown();
	    browsersetup.loadPage(5000);
	    ut =  new util(driver);
		ut.ListValues(CAPOP.APIProvider_DropdownValues(), APIProvider);
		browsersetup.loadPage(2000);
	   
	}

	@Then("^User click on Discover button$")
	public void user_click_on_Discover_button() throws Throwable {
		browsersetup.loadPage(5000);
	    CAPOP.Discover();
	   
	}

	@Then("^User enters Search data\"([^\"]*)\"$")
	public void user_enters_Search_data(String SearchData) throws Throwable {
		browsersetup.loadPage(5000);
	    CAPOP.APISearchInput(SearchData);
	   
	}

	@Then("^User click on Radio button$")
	public void user_click_on_Radio_button() throws Throwable {
	    
		browsersetup.loadPage(5000);
	    CAPOP.RadioButoon();
	    browsersetup.loadPage(5000);
	    CAPOP.OKButton();
	}

	@Then("^User click on API Provider Create button$")
	public void user_click_on_API_Provider_Create_button() throws Throwable {
		browsersetup.loadPage(5000);
	    CAPOP.CreateAPIButton();
	   
	}

	@Then("^User click on Save button$")
	public void user_click_on_Save_button() throws Throwable {
		browsersetup.loadPage(10000);
	    CAPOP.SaveBtn();
	   
	}
	
	@Then("^User click on Policy button$")
	public void user_click_on_Policy_button() throws Throwable {
	    
		browsersetup.loadPage(8000);
	    CAPOP.PoliciesButton();
	}

	
	
	
	//////////////
	
	@Then("^User click on Edit button$")
	public void user_click_on_Edit_button() throws Throwable {
		browsersetup.loadPage(8000);
	    CAPOP.EditButton();
	   
	}

	@Then("^User expand TargetEndPoint$")
	public void user_expand_TargetEndPoint() throws Throwable {
		browsersetup.loadPage(8000);
	    CAPOP.TargetEndPoint();
	 //   ut.javascriptclick(CAPOP.TargetEndPointBtn());
	    browsersetup.loadPage(8000);
	}

	@Then("^User click on PostFlow$")
	public void user_click_on_PostFlow() throws Throwable {
	    
		browsersetup.loadPage(8000);
	    CAPOP.PostFlowButton();
	}

	@Then("^User click on Basiv Authetication add button$")
	public void user_click_on_Basiv_Authetication_add_button() throws Throwable {
		browsersetup.loadPage(3000);
	    CAPOP.BasicAuthenticationButton();
	   
	}

	@Then("^User enters policy name for Basic Authetication\"([^\"]*)\"$")
	public void user_enters_policy_name_for_Basic_Authetication(String Basicpolicyname) throws Throwable {
		browsersetup.loadPage(8000);
	    CAPOP.PolicyName(Basicpolicyname);
	   
	}
	
	@Then("^User enters policy name for KeyValue Map Operation\"([^\"]*)\"$")
	public void user_enters_policy_name_for_KeyValue_Map_Operation(String KVMpolicyname) throws Throwable {
		browsersetup.loadPage(8000);
	    CAPOP.PolicyName(KVMpolicyname);
	}

	@Then("^User click on Add button$")
	public void user_click_on_Add_button() throws Throwable {
	    
		browsersetup.loadPage(8000);
	    CAPOP.CreatePolicyAddBtn();
	}

	@Then("^User click on KeyValue Map Operation add button$")
	public void user_click_on_KeyValue_Map_Operation_add_button() throws Throwable {
		browsersetup.loadPage(8000);
	    CAPOP.KeyValueMapOperation();
	   
	}




}
