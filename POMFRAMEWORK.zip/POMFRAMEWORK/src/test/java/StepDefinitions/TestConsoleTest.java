package StepDefinitions;

import BaseClass.browsersetup;
import PageObjectory.CreateApiProvider_OnPremisePage;
import Utilities.util;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import junit.framework.Assert;

public class TestConsoleTest extends browsersetup{
	
	CreateApiProvider_OnPremisePage CAPOP;
	util ut;

	
	
	
	@Given("^User click on TestConsole tab$")
	public void user_click_on_TestConsole_tab() throws Throwable {
		browsersetup.loadPage(10000);
		CAPOP =  new CreateApiProvider_OnPremisePage(driver);
		CAPOP.TestConsoleTab();
	    
	}

	@Then("^User enters on API data\"([^\"]*)\"$")
	public void user_enters_on_API_data(String APIDATA) throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.setAPIData(APIDATA);
	}

	@Then("^User select API data\"([^\"]*)\"$")
	public void user_select_API_data(String APIProvider) throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.APIValueSelection();
	//	ut =  new util(driver);
	///	ut.ListValues(CAPOP.SelectAPIValue(), APIProvider);
		browsersetup.loadPage(2000);
	    
	}

	@Then("^User select Authentication\"([^\"]*)\"$")
	public void user_select_Authentication(String Authentication) throws Throwable {
		browsersetup.loadPage(5000);
		CAPOP.AuthenticationArrowBtn();
		browsersetup.loadPage(5000);
		ut= new util(driver);
		ut.ListValues(CAPOP.AuthenticationDropdownValue(), Authentication);
		browsersetup.loadPage(2000);
	    
	}

	@Then("^User click on send button$")
	public void user_click_on_send_button() throws Throwable {
	    CAPOP.SendBtn();
	    browsersetup.loadPage(5000);
	    
	}

	@Then("^verify status code\"([^\"]*)\"$")
	public void verify_status_code(String statuscode) throws Throwable {
	    String statusverify = CAPOP.StatusCode();
	    System.out.println(statusverify);
	    Assert.assertEquals(statusverify, statuscode);
	    
	}



}
