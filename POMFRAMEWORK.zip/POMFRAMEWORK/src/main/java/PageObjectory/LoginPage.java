package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.browsersetup;

public class LoginPage extends browsersetup{
	
	
	public LoginPage(WebDriver driver) {
		browsersetup.driver= driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//input[@id='j_username']")
	private WebElement UserName;
	
	@FindBy(xpath = "//button[@id='logOnFormSubmit']")
	private WebElement ContinueBtn;
	
	@FindBy(xpath = "//input[@id='j_password']")
	private WebElement Password;
	
	@FindBy(xpath = "//button[contains(text(),'Log On')]")
	private WebElement LogOnBtn;
	
	
	public void UserName(String value) {
		UserName.sendKeys(value);
	}
	
	public void ContinueBtn() {
		ContinueBtn.click();
	}
	
	public void Password(String value) {
		Password.sendKeys(value);
	}
	
	public void LogOnBtn() {
		LogOnBtn.click();;
	}

}
