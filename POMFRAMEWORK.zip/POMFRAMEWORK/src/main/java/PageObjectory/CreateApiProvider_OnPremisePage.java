package PageObjectory;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.browsersetup;

public class CreateApiProvider_OnPremisePage extends browsersetup {

	public CreateApiProvider_OnPremisePage(WebDriver driver) {
		browsersetup.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Overview

	@FindBy(xpath = "//a[@id='configure-a']")
	private WebElement ConfigureTab;

	@FindBy(xpath = "//bdi[contains(@id,'__button')]")
	private WebElement CreateBtn;

	@FindBy(xpath = "//input[@id='__input0-inner']")
	private WebElement Name;

	@FindBy(xpath = "//textarea[@id='__area0-inner']")
	private WebElement Description;

	// Connection

	@FindBy(xpath = "(//bdi[contains(text(),'Connection')])[2]")
	private WebElement ConnectionLink;

	@FindBy(xpath = "(//span[@class='sapMSltLabel'])[1]")
	private WebElement Connection_Type;

	@FindBy(xpath = "//ul[@id='__list2']/li")
	private List<WebElement> Connection_TypeList;

	public List<WebElement> Connection_TypeList() {
		return Connection_TypeList;
	}

	@FindBy(xpath = "(//input[@class='sapMInputBaseInner'])[1]")
	private WebElement Connection_Host;

	@FindBy(xpath = "(//input[@class='sapMInputBaseInner'])[2]")
	private WebElement Connection_Port;

	@FindBy(xpath = "(//input[@class='sapMInputBaseInner'])[3]")
	private WebElement Connection_LocationId;

	@FindBy(xpath = "(//input[@class='sapMInputBaseInner'])[4]")
	private WebElement Connection_Input_AdditionalProperties;

	@FindBy(xpath = "(//span[@class='sapMSltLabel'])[2]")
	private WebElement Connection_Authetication;

	@FindBy(xpath = "//ul[@id='__list3']/li")
	private List<WebElement> Connection_AutheticationList;

	public List<WebElement> Connection_AutheticationList() {
		return Connection_AutheticationList;
	}

	@FindBy(xpath = "(//span[@class='sapMSltLabel'])[3]")
	private WebElement Connection_AdditionalProperties;

	@FindBy(xpath = "//ul[@id='__list4']/li")
	private List<WebElement> Connection_AdditionalPropertiesList;

	public List<WebElement> Connection_AdditionalPropertiesList() {
		return Connection_AdditionalPropertiesList;
	}

	// Overview Methods
	public void clickOnConfigureTab() {
		ConfigureTab.click();
	}

	public void clickOnCreateBtn() {
		CreateBtn.click();
	}

	public void setName(String value) {
		Name.sendKeys(value);
	}

	public void setDescription(String value) {
		Description.sendKeys(value);
	}

	// Connection Methods
	public void ClickOnConnectionLink() {
		ConnectionLink.click();
	}

	public void ClickOnConnection_Type() {
		Connection_Type.click();
	}

	public void Connection_Host(String value) {
		Connection_Host.sendKeys(value);
	}

	public void Connection_Port(String value) {
		Connection_Port.sendKeys(value);
	}

	public void Connection_LocationId(String value) {
		Connection_LocationId.sendKeys(value);
	}

	public void Connection_Input_AdditionalProperties(String value) {
		Connection_Input_AdditionalProperties.sendKeys(value);
	}

	public void ClickOnConnection_AdditionalProperties() {
		Connection_AdditionalProperties.click();
	}

	public void ClickOnConnection_Authetication() {
		Connection_Authetication.click();
	}

	// Catalog Service Settings
	@FindBy(xpath = "//bdi[contains(text(),'Catalog Service Settings')]")
	private WebElement CatalogServiceSettings;

	public void ClickOnCatalogServiceSettings() {
		CatalogServiceSettings.click();
	}

	@FindBy(xpath = "(//input[@class='sapMInputBaseInner'])[1]")
	private WebElement PathPrefix;

	public void PathPrefix(String value) {
		PathPrefix.sendKeys(value);
	}

	@FindBy(xpath = "(//input[@class='sapMInputBaseInner'])[2]")
	private WebElement ServiceCollectionUrl;

	public void ServiceCollectionUrl(String value) {
		ServiceCollectionUrl.sendKeys(value);
	}

	@FindBy(xpath = "//span[@class='sapMSltLabel']")
	private WebElement AutheticationType;

	public void ClickOnAutheticationType() {
		AutheticationType.click();
	}

	@FindBy(xpath = "//ul[@id='__list7']/li")
	private List<WebElement> AutheticationType_List;

	public List<WebElement> AutheticationType_List() {
		return AutheticationType_List;
	}

	@FindBy(xpath = "//input[contains(@id,'--username-inner')]")
	private WebElement UserName;

	public void UserName(String value) {
		UserName.sendKeys(value);
	}

	@FindBy(xpath = "//input[contains(@id,'--password-inner')]")
	private WebElement Password;

	public void Password(String value) {
		Password.sendKeys(value);
	}

	@FindBy(xpath = "//bdi[contains(text(),'Save')]")
	private WebElement SaveBtn;

	public void SaveBtn() {
		SaveBtn.click();
	}

	@FindBy(xpath = "//bdi[contains(text(),'Test Connection')]")
	private WebElement TestConnectionBtn;

	public void TestConnectionBtn() {
		TestConnectionBtn.click();
	}

	@FindBy(xpath = "//div[@class='sapMMsgStripMessage']/span")
	private WebElement TestConnectionSuccessMessage;

	public String TestConnectionSuccessMessage() {
		return TestConnectionSuccessMessage.getText();
	}

	// Develop Scenario
	@FindBy(xpath = "//a[@id='develop-a']")
	private WebElement DevelopTab;

	public void DevelopTab() {
		DevelopTab.click();
	}

	@FindBy(xpath = "(//bdi[contains(@id,'__button')])[1]")
	private WebElement Develop_CreateButon;

	public void Develop_CreateButon() {
		Develop_CreateButon.click();
	}

	@FindBy(xpath = "//*[@class='sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer sapMInputBaseIcon']")
	private WebElement APIProvider_Dropdown;

	public void APIProvider_Dropdown() {
		APIProvider_Dropdown.click();
	}

	@FindBy(xpath = "//*[@class='sapMListItems sapMListUl sapMListShowSeparatorsNone sapMListModeSingleSelectMaster']/li/div/div/div")
	private List<WebElement> APIProvider_DropdownValues;

	public List<WebElement> APIProvider_DropdownValues() {
		return APIProvider_DropdownValues;
	}

	@FindBy(xpath = "//bdi[contains(text(),'Discover')]")
	private WebElement Discover;

	public void Discover() {
		Discover.click();
	}

	@FindBy(xpath = "(//input[@class='sapMSFI'])[1]")
	private WebElement APISearchInput;

	public void APISearchInput(String value) {
		APISearchInput.sendKeys(value);
	}

	@FindBy(xpath = "//*[name()='circle' and contains(@class,'sapMRbBInn')]")
	private WebElement RadioButoon;

	public void RadioButoon() {
		RadioButoon.click();
	}

	@FindBy(xpath = "//*[contains(text(),'OK')]")
	private WebElement OKButton;

	public void OKButton() {
		OKButton.click();
	}

	@FindBy(xpath = "(//*[contains(text(),'Create')])[2]")
	private WebElement CreateAPIButton;

	public void CreateAPIButton() {
		CreateAPIButton.click();
	}

	@FindBy(xpath = "//bdi[contains(text(),'Policies')]")
	private WebElement PoliciesButton;

	public void PoliciesButton() {
		PoliciesButton.click();
	}

	@FindBy(xpath = "(//*[@id='__panel1-content']/div[2]/div/div/button/span/span)[1]")
	private WebElement TargetEndPoint;

	public void TargetEndPoint() {
		TargetEndPoint.click();
	}

	public WebElement TargetEndPointBtn() {
		return TargetEndPoint;
	}

	@FindBy(xpath = "(//*[contains(text(),'Edit')])[2]")
	private WebElement EditButton;

	public void EditButton() {
		EditButton.click();
	}

	@FindBy(xpath = "//*[@title='PostFlow']")
	private WebElement PostFlowButton;

	public void PostFlowButton() {
		PostFlowButton.click();
	}

	@FindBy(xpath = "//*[@class='sapMListItems sapMListUl sapMListShowSeparatorsAll sapMListModeNone']/li[2]/div/span[4]/span")
	private WebElement BasicAuthenticationButton;

	public void BasicAuthenticationButton() {
		BasicAuthenticationButton.click();
	}

	@FindBy(xpath = "//*[@class='sapMInputBaseInner']")
	private WebElement PolicyName;

	public void PolicyName(String value) {
		PolicyName.sendKeys(value);
	}

	@FindBy(xpath = "(//*[contains(text(),'Add')])[1]")
	private WebElement CreatePolicyAddBtn;

	public void CreatePolicyAddBtn() {
		CreatePolicyAddBtn.click();
	}

	@FindBy(xpath = "//*[@class='sapMListItems sapMListUl sapMListShowSeparatorsAll sapMListModeNone']/li[30]/div/span[4]/span")
	private WebElement KeyValueMapOperation;

	public void KeyValueMapOperation() {
		KeyValueMapOperation.click();
	}
	
	
	//TestConsole
	@FindBy(xpath = "//a[@id='testconsole-a']")
	private WebElement TestConsoleTab;
	
	public void TestConsoleTab() {
		TestConsoleTab.click();
	}
	
	@FindBy(xpath = "//*[@class='sapMSFI']")
	private WebElement APIData;
	
	public void setAPIData(String value) {
		APIData.sendKeys(value);
	}
	
	
	@FindBy(xpath = "//*[@id='__xmlview11--apiList-listUl']/li/div/div/div")
	private List<WebElement> SelectAPIValue;
	
	public List<WebElement> SelectAPIValue() {
		return SelectAPIValue;
	}
	
	
	@FindBy(xpath = "//*[@class='sapMListItems sapMListUl sapMListShowSeparatorsAll sapMListModeSingleSelectMaster']/li/div/div/div")
	private WebElement APIValueSelection;
	
	public void APIValueSelection() {
		APIValueSelection.click();
	}
	
	@FindBy(xpath = "//*[@class='sapUiIcon sapUiIconMirrorInRTL sapUiIconPointer sapMInputBaseIcon']")
	private WebElement AuthenticationArrowBtn;
	
	public void AuthenticationArrowBtn() {
		AuthenticationArrowBtn.click();
	}
	
	
	@FindBy(xpath = "//*[@class='sapMListItems sapMListUl sapMListShowSeparatorsNone sapMListModeSingleSelectMaster']/li/div/div/div")
	private List<WebElement> AuthenticationDropdownValue;
	
	public List<WebElement> AuthenticationDropdownValue() {
		return AuthenticationDropdownValue;
	}
	
	
	@FindBy(xpath = "//*[contains(text(),'Send')]")
	private WebElement SendBtn;
	
	public void SendBtn() {
		SendBtn.click();
	}
	
	
	
	
	@FindBy(xpath = "//*[@class='sapMBarPH sapMBarContainer']/span[2]/span/bdi")
	private WebElement StatusCode;
	
	public String StatusCode() {
		return StatusCode.getText();
	}
	
	
	

}
