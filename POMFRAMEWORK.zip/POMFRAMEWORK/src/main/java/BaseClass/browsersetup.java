package BaseClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class browsersetup {
	
	public static WebDriver driver;
	
	public static WebDriver startBrowser(String browserName, String url) {
		
		if(browserName.equalsIgnoreCase("Edge")) {
			WebDriverManager.edgedriver().setup();
			 driver=new EdgeDriver();
		}else
			if(browserName.equalsIgnoreCase("Chrome")) {
				WebDriverManager.chromedriver().setup();
				 driver=new ChromeDriver();
			}else
				if(browserName.equalsIgnoreCase("Firefox")) {
					WebDriverManager.firefoxdriver().setup();
					 driver=new FirefoxDriver();
					}
		driver.manage().window().maximize();
	   driver.manage().deleteAllCookies();
	   driver.get(url);
		return driver;
		
	}
	
	public static void loadPage(Integer milliseconds) {
		try {
			TimeUnit.MILLISECONDS.sleep(milliseconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	

}
