package Utilities;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import BaseClass.browsersetup;

public class util extends browsersetup{
	
	
	public util(WebDriver driver) {
		browsersetup.driver= driver;
		PageFactory.initElements(driver,this);
	}
	
	
	public void javascriptclick(WebElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", ele);
	}
	
	public void ListValues(List<WebElement> ele, String value) {
		
		List<WebElement> datalist = ele;
		System.out.println(datalist.size());
		
		for(WebElement eledata : datalist) {
			browsersetup.loadPage(500);
			System.out.println(eledata.getAttribute("innerHTML"));
			browsersetup.loadPage(200);
			if(eledata.getAttribute("innerHTML").equals(value)) {
				browsersetup.loadPage(200);
				eledata.click();
				break;
			}
		}
		
		
	}
}
